#!/usr/bin/env bash

echo Reset successful
