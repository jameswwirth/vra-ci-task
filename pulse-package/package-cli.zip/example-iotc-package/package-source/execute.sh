#!/usr/bin/env bash

# Sample commands the script could do
echo $(date "+%Y-%m-%d %H:%M:%S") Execution script started >> execution_log.txt
echo Doing some execution work!
echo $(date "+%Y-%m-%d %H:%M:%S") Execution script finished >> execution_log.txt