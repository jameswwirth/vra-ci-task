#!/usr/bin/env bash

echo Actiovation successful
