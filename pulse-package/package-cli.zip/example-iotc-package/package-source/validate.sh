#!/usr/bin/env bash

echo Validation successful
